
//*************************************************************************** 
//*  
//*       CIS 340                  Spring 2023                  Caleb Jones 
//*  
//*                     Programming Assignment: CalebJonesPA04
//*  
//* 				Class description (can be multiple lines) 
//*   		           This is my submission for the
//*  
//*  							 :)
//*                             Date Created: 
//*  						  (Mar 1, 2023)
//*                       File Name:  CalebJonesPA04.java
//*  							
//****************************************************************************
package PAs;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;

import javax.swing.JOptionPane;



public class CalebJonesPA04 {
	
	String firstName = " ";
	String lastName = " ";
	static int[] points = new int[7];  // to store points given by 7 judges
	static int difficultyLevel;  // to store the diving difficulty level
	static double avgPoints;
	static double finalScore;
	static String out = " ";
	static int noOfCompetitors;
	
	

	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub
		int noOfDivers = 0;
		try {
			noOfDivers = Integer.parseInt(JOptionPane.showInputDialog(null,"Enter The number of Divers"));
			
			if(noOfDivers<1 || noOfDivers >10) {
				throw new Exception();
		}
		}catch(Exception ex) {
			JOptionPane.showMessageDialog(null,"Please enter a valid number of divers");
	}
		divingCompetitor(noOfDivers);
		
		
		
		
		
		
		for (int i = 0; i<noOfCompetitors; i++) {
			
			//input customer rate - Use the Validation Methods in class DataEntries
			//diveDiff = DataEntries.intInput("Input Difficulty Level (1-5)");
					
			

	}
	}
	public static void divingCompetitor (int noOfDivers) throws FileNotFoundException {
		int difficultyLevel = 0;
		int totalPoints = 0;
		String firstName = " ";
		String lastName = " ";
		double avgPoints;
		//arrays
		int points[];
		double finalScore[];
		
		
		finalScore = new double[noOfDivers];
		String competitorArr[] = new String[noOfDivers];
		
		//for putting in information
		for(int i = 0; i< noOfDivers;i++) {
			try {
				firstName = JOptionPane.showInputDialog(null,"Enter First Name of Diver");
				
				if(firstName.isEmpty()) {
					throw new Exception();
			}
			}catch(Exception ex) {
				JOptionPane.showMessageDialog(null,"Please enter a valid name");
		}
			
			try {
				lastName = JOptionPane.showInputDialog(null,"Enter Last Name of Diver");
				
				if(lastName.isEmpty()) {
					throw new Exception();
			}
			}catch(Exception ex) {
				JOptionPane.showMessageDialog(null,"Please enter a valid name");
		}
			try {
				difficultyLevel = Integer.parseInt(JOptionPane.showInputDialog(null,"Enter The Difficulty Level"));
				
				if(difficultyLevel<1 || difficultyLevel >5) {
					throw new Exception();
			}
			}catch(Exception ex) {
				JOptionPane.showMessageDialog(null,"Please enter a valid number of divers");
		}
		points = new int[7];
		generatePoints();
		
		for (int j = 0; j< points.length;j++) {
			totalPoints+= points[j];
		}
		avgPoints = getAvg(points, totalPoints);
		
		finalScore[i] = getFinalScore(avgPoints, difficultyLevel);
		
		competitorArr[i] = firstName + lastName + "\t\t";
		
		out +="\n " + competitorArr[i]+ "\t\t" + String.format("%.2f", finalScore[i]);
		}
		sortCompetitorArray(finalScore, competitorArr);
		
		writeToFile(competitorArr, finalScore);
	}
	public static void generatePoints() {
		for(int i = 0; i <=7;i++) {
			points[i] = (int) (Math.random() * 10 + 1);
		}

	}
	public static double getAvg(int []points, int totalPoints) {
		int currentMinIndex = 0;
		int currentMaxIndex = 0;
		for (int i = 0; i < points.length - 1; i++) {
		      // Find the minimum in the list[i..list.length-1]
		      double currentMin = points[i];
		      currentMinIndex = i;

		      for (int j = i + 1; j < points.length; j++) {
		        if (currentMin > points[j]) {
		          currentMin = points[j];
		          currentMinIndex = j;
		        }
		      }
		}
		      for (int i = 0; i < points.length - 1; i++) {
			      // Find the minimum in the list[i..list.length-1]
			      double currentMax = points[i];
			      currentMaxIndex = i;

			      for (int j = i + 1; j < points.length; j++) {
			        if (currentMax < points[j]) {
			          currentMax = points[j];
			          currentMaxIndex = j;
			        }
			      }
	}
		      for(int i = 0;i<points.length-2;i++) {
		    	  if(i == currentMaxIndex || i==currentMinIndex) {
		    		  i++;
		    	  }else {
		    		  avgPoints += i;
		    	  }
		      }
		      avgPoints = avgPoints / (points.length-2);
		      return avgPoints;
		}
		
	
	public static double getFinalScore (double avgPoints, int difficultyLevel) {
		double finalScore = 0;
		finalScore = avgPoints * 3 * difficultyLevel;
		
			
		return finalScore;
	}

	public static void sortCompetitorArray (double []finalScore, String[] competitorArr) {
		int i,j;
		for(i = 0;i< finalScore.length - 1;i++) {
			int currentMinIndex = i;
			double currentMin = finalScore[i];
			String currentMinInfo = competitorArr[i];
			
			for(j = i+1; j<finalScore.length;j++) {
				if(finalScore[j] < currentMin) {
					currentMinInfo = competitorArr[j];
					currentMinIndex = j;
				}
			}
			if(currentMinIndex !=j) {
				finalScore[currentMinIndex] = finalScore[i];
				finalScore[i] = currentMin;
				
				competitorArr[currentMinIndex] = competitorArr[i];
				competitorArr[i] = currentMinInfo;
				
			}
			
		
	}

		JOptionPane.showMessageDialog(null,"Finished Sorting Competitors");
	}

// end intInput()
	public static void writeToFile(String[] competitorArr, double[] finalScore) throws FileNotFoundException {
	
		
		File file = new File("Scores.txt");
		
		PrintWriter write = new PrintWriter(file);
		
		String out = "Diver Name\t\tFinal Score";
		for(int i =0; i<competitorArr[i].length();i++) {
			out+= "\n" + competitorArr[i].toString() + String.format("%.2f",finalScore[i]).toString();
		}
		write.print(out);
		
		write.close();
		JOptionPane.showMessageDialog(null,"Done sorting into file");
}
	
}

