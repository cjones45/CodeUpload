import numpy as np
a = np.array([1,2, 3, []]) 
a[-1].append(4)
a[-1].append(5)
print(len(a))